<?php

define('SSS_SITEKEY', '6Lei_-oUAAAAADuJzjo-pm4BducmykjPymlibiPv');
define('SSS_SECRETKEY', '6Lei_-oUAAAAAC8S3_oftUfr4qsWLC-BuKtRmPTp');

class Captcha
{
    private static $_instance = null;

    /**
     * @return WP_reCaptcha
     */
    public static function instance()
    {
        if (is_null(self::$_instance))
            self::$_instance = new self();
        return self::$_instance;
    }

    private function __construct()
    {
        add_action('init', array($this, 'init'), 11);

        add_action('wp_footer', array($this, 'captcha_footer'));
        add_action('login_footer', array($this, 'captcha_footer'),100);

    }

    function init()
    {

        add_action('login_form',array(&$this,'print_recaptcha_html'));
        add_filter('wp_authenticate_user',array(&$this,'deny_login'),99 );

        add_action('lostpassword_form' , array($this,'print_recaptcha_html') );
        add_action('lostpassword_post' , array(&$this,'recaptcha_check_or_die') , 99 );

        add_filter('comment_form_submit_button',array($this,'prepend_recaptcha_html'),10,2);
        add_action('pre_comment_on_post',array($this,'recaptcha_check_or_die'));

        add_action('register_form',array($this,'print_recaptcha_html'));
        add_filter('registration_errors',array(&$this,'registration_errors'));


        if (function_exists('WC') || class_exists('WooCommerce')) {
            //add_action('woocommerce_review_order_before_submit', array($this, 'print_recaptcha_html'), 10, 0);
           // add_action('woocommerce_checkout_process', array(&$this, 'recaptcha_check'));
           // add_filter('wc_checkout_recaptcha_html', array(&$this, 'print_recaptcha_html'));

            add_action('woocommerce_login_form', array($this, 'print_recaptcha_html'), 10, 0);
            add_filter('woocommerce_process_login_errors', array(&$this, 'login_errors'), 10, 3);

            if (class_exists('WooCommerce')) {
                global $woocommerce;
                add_action('woocommerce_register_form', array($this, 'print_recaptcha_html'), 10, 0);
            }

            add_filter('woocommerce_registration_errors', array(&$this, 'login_errors'), 10, 3);
            add_filter('woocommerce_form_field_recaptcha', array($this, 'print_recaptcha_html'), 10, 3);
            add_action('woocommerce_lostpassword_form', array($this, 'print_recaptcha_html'), 10, 0);

        }
    }
    function registration_errors( $errors ) {
        if ( isset( $_POST["user_login"]) )
            $errors = $this->wp_error_add( $errors );
        return $errors;
    }

    function wp_error_add( $param , $error_code = 'captcha_error' ) {
        if ( ! $this->check() ) {
            return new WP_Error( $error_code ,  __("<strong>Error:</strong> the Captcha didn’t verify.",'cosmeagardens') );
        } else {
            return $param;
        }
    }

    function prepend_recaptcha_html( $html ) {
        return $this->print_recaptcha_html() . $html;
    }


    function recaptcha_check_or_die( ) {
        if ( ! $this->check() ) {
            $err = new WP_Error('comment_err',  __("<strong>Error:</strong> the Captcha didn’t verify.",'cosmeagardens') );
            wp_die( $err );
        }
    }

    function check()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recaptcha_response'])) {

            // Build POST request:
            $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
            $recaptcha_secret = SSS_SECRETKEY;
            $recaptcha_response = $_POST['recaptcha_response'];

            // Make and decode POST request:
            $recaptcha = file_get_contents($recaptcha_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response);
            $recaptcha = json_decode($recaptcha);

            // Take action based on the score returned:
            if ($recaptcha->score >= 0.5) {
                return true;
            } else {
                return false;
            }

        }
    }

    function login_errors( $validation_error ) {
        if ( !$this->check() )
            $validation_error->add( 'captcha_error' ,  __("<strong>Error:</strong> the Captcha didn’t verify.",'cosmeagardens') );
        return $validation_error;
    }

    function recaptcha_check()
    {
        if (!$this->check())
            wc_add_notice(__("<strong>Error:</strong> the Captcha didn’t verify.", 'cosmeagardens'), 'error');
    }

    function deny_login( $user ) {
   
        if ( isset( $_POST["log"]) && !$this->check() ) {
            $msg = __("<strong>Error:</strong> Captcha is not verify.",'cosmeagardens');
//            if ( in_array( 'administrator' , $user->roles )  ) {
//                return $user;
//            }
            return new WP_Error( 'captcha_error' , $msg );
        }
        return $user;
    }



    function print_recaptcha_html()
    {
        ?>

        <input type="hidden" name="recaptcha_response" id="g-recaptcha-response"/>

        <?php
    }

    function captcha_footer()
    {
        $recaptcha_api_url = "https://www.google.com/recaptcha/api.js";
        $recaptcha_api_url = add_query_arg(array(
            'render' => SSS_SITEKEY,
        ), $recaptcha_api_url);
        ?>
        <script src="<?php echo esc_url($recaptcha_api_url) ?>" async defer></script><?php
        ?>
        <script>
            sssprepare = function () {
                grecaptcha.ready(function () {
                    grecaptcha.execute("<?php echo SSS_SITEKEY;  ?>", {action: 'SSS_reCaptcha'}).then(function (token) {
                        document.querySelectorAll("#g-recaptcha-response").forEach(function (elem) {
                            elem.value = token
                        });
                    });
                });
            };

            jQuery(document).ready(function ($) {
                var tryCounter = 0,
                    /* launching timer so that the function keeps trying to display the reCAPTCHA again and again until google js api is loaded */
                    ssscapthca_timer = setInterval(function () {
                        if (typeof Recaptcha != "undefined" || typeof grecaptcha != "undefined") {
                            try {
                                sssprepare();
                            } catch (e) {
                                console.log('Unexpected error occurred: ', e);
                            }
                            clearInterval(ssscapthca_timer);
                        }
                        tryCounter++;
                        /* Stop trying after 10 times */
                        if (tryCounter >= 10) {
                            clearInterval(ssscapthca_timer);
                        }
                    }, 1000);

                function ssscapthca_prepare() {
                    if (typeof Recaptcha != "undefined" || typeof grecaptcha != "undefined") {
                        try {
                            sssprepare();
                        } catch (err) {
                            console.log(err);
                        }
                    }
                }

                $(window).on('load', ssscapthca_prepare);

                $('.woocommerce').on('click', '.woocommerce-tabs', ssscapthca_prepare);

                $('#recaptcha_widget_div').on('input paste change', '#recaptcha_response_field', cleanError);
            });

            function cleanError() {
                $error = $(this).parents('#recaptcha_widget_div').next('#ssscapthca_error');
                if ($error.length) {
                    $error.remove();
                }
            }

            function get_id() {
                var id = 'ssscapthca_recaptcha_' + Math.floor(Math.random() * 1000);
                if ($('#' + id).length) {
                    id = get_id();
                } else {
                    return id;
                }
            }
        </script>
        <?php
    }
}

Captcha::instance();
