<?php

add_action('wp_ajax_sss_register_action', 'sss_register_action');
add_action('wp_ajax_nopriv_sss_register_action', 'sss_register_action');
if (!function_exists('sss_register_action')) {
    function sss_register_action()
    {

        if (!empty($_GET['et_register'])) {

            if (isset($_REQUEST['recaptcha_response'])) {

                // Build POST request:
                $recaptcha_url = 'https://www.google.com/recaptcha/api/siteverify';
                $recaptcha_secret = SSS_SECRETKEY;
                $recaptcha_response = $_POST['recaptcha_response'];

                // Make and decode POST request:
                $recaptcha = file_get_contents($recaptcha_url . '?secret=' . $recaptcha_secret . '&response=' . $recaptcha_response);
                $recaptcha = json_decode($recaptcha);

                // Take action based on the score returned:
                if ($recaptcha->score >= 0.5) {

                } else {
                    $return['status'] = 'error';
                    $return['msg'] = __("Captch not Verify.", ETHEME_DOMAIN);
                    echo json_encode($return);
                    die();
                }

            }
            $email = esc_sql($_REQUEST['email']);
            if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/", $email)) {
                $return['status'] = 'error';
                $return['msg'] = __("Please enter a valid email.", ETHEME_DOMAIN);
                echo json_encode($return);
                die();
            }

            $telephone_numb = esc_sql($_REQUEST['telephone']);
            $pass = esc_sql($_REQUEST['et_pass']);
            $pass2 = esc_sql($_REQUEST['et_pass2']);
            if (empty($pass) || !preg_match('/^[a-zA-Z-#@$?]{6,30}[0-9]{1,10}$/', $pass)) {
                //if(empty($pass) || !preg_match('/^[a-z]{6,30}[0-9]{1,10}$/', $pass)) {
                $return['status'] = 'error';
                $return['msg'] = __("<strong>Please create a password with at least 6 letters and 1 number</strong>", ETHEME_DOMAIN);
                echo json_encode($return);
                die();
            }
            if ($pass != $pass2) {
                $return['status'] = 'error';
                $return['msg'] = __("The passwords do not match", ETHEME_DOMAIN);
                echo json_encode($return);
                die();
            }

            $status = wp_create_user($email, $pass, $email, $telephone_numb);
            // print_r($status);
            update_usermeta($status, 'telephone_num', $telephone_numb);
            if (is_wp_error($status)) {
                $return['status'] = 'error';
                $return['msg'] = __("Email already exists. Please try another one.", ETHEME_DOMAIN);
                echo json_encode($return);
            } else {
                $from = get_bloginfo('name');
                $from_email = get_bloginfo('admin_email');
                //$headers = 'From: '.$from . " <". $from_email .">\r\n";
                //$headers .= "MIME-Version: 1.0\r\n";
                $headers = "Content-type: text/html;" . PHP_EOL;
                //$headers .= "Content-Transfer-Encoding: quoted-printable". PHP_EOL;
                $subject = __("Welcome to CosmeaGardens - Registration Successful", ETHEME_DOMAIN);
                //$subject2admin = __("New user registration", ETHEME_DOMAIN);
                $message = et_registration_email($email);
                //$message2admin = et_registration_admin_email($email);
                wp_mail($email, $subject, $message, $headers);
                //wp_mail( get_option('admin_email'), $subject2admin, $message2admin, $headers );
                $return['status'] = 'success';
                $return['msg'] = __("Please check your email for login details.", ETHEME_DOMAIN);
                $return['url'] = get_permalink(wc_get_page_id('myaccount'));
                echo json_encode($return);

            }
            die();
        }
    }
}