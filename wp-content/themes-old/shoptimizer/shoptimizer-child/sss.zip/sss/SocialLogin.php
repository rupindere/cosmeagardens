<?php

define('SSS_FBKEY', '1151936305158619');

define('SSS_GOOGLEKEY', '676810173682-ng4feff6v972g6olce047rfm8e4udtlb.apps.googleusercontent.com');

class SocialLogin
{

    private static $_instance = null;

    /**
     * @return WP_reCaptcha
     */
    public static function instance()
    {
        if (is_null(self::$_instance))
            self::$_instance = new self();
        return self::$_instance;
    }

    private function __construct()
    {
        add_action('wp_head', array($this, 'add_meta'));
        add_action('login_head', array($this, 'add_meta'));
        add_action('wp_footer', array($this, 'fb_footer'));
        add_action('login_footer', array($this, 'fb_footer'), 100);
        add_action('register_form', array($this, 'fb_html'));
        add_action('login_form', array($this, 'fb_html'));
        add_action('woocommerce_login_form', array($this, 'fb_html'));

        add_action('wp_ajax_sss_socialLoginAction', array($this, 'socialLoginAction'));
        add_action('wp_ajax_nopriv_sss_socialLoginAction', array($this, 'socialLoginAction'));

    }

    function fb_footer()
    {
        ?>
        <script>

            function statusChangeCallback(response) {  // Called with the results from FB.getLoginStatus().
                if (response.status === 'connected') {   // Logged into your webpage and Facebook.
                    sssFacebookApi();
                }
            }

            function checkLoginState() {

                // Called when a person is finished with the Login Button.
                FB.login(function (response) {   // See the onlogin handler
                    statusChangeCallback(response);
                });
            }

            window.fbAsyncInit = function () {
                FB.init({
                    appId: "<?php echo SSS_FBKEY; ?>",
                    cookie: true,                     // Enable cookies to allow the server to access the session.
                    xfbml: true,                     // Parse social plugins on this webpage.
                    version: 'v6.0'           // Use this Graph API version for this call.
                });

                //    FB.getLoginStatus(function (response) {   // Called after the JS SDK has been initialized.
                //      statusChangeCallback(response);        // Returns the login status.
                // })
            };

            (function (d, s, id) {                      // Load the SDK asynchronously
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s);
                js.id = id;
                js.src = "https://connect.facebook.net/en_US/sdk.js";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));

            function sssFacebookApi() {
                FB.api('/me?fields=id,name,email,first_name,last_name', function (response) {
                    sssSocialLogin(response.email, response.id, 'facebook', response.first_name,
                        response.last_name)
                });
            }



            function sssSocialLogin(email, id, type, firstname, lastname) {

                var fd = new FormData();

                fd.append('action', 'sss_socialLoginAction');
                fd.append('sss_sociallogin', '1');
                fd.append('email', email);
                fd.append('id', id);
                fd.append('type', type);
                fd.append('first_name', firstname);
                fd.append('last_name', lastname);

                xhr = new XMLHttpRequest();

                xhr.open( 'POST', "<?php echo admin_url('admin-ajax.php'); ?>", true );
                xhr.onreadystatechange = function ( response ) {
                    if(response.status =='error'){
                    }else{
                        window.location.href = "/my-account";
                    }
                    //  location.reload(true);
                };
                xhr.send( fd );

            }

            // function onSignIn(googleUser) {
            //     var profile = googleUser.getBasicProfile();
            //     console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
            //     console.log('Name: ' + profile.getName());
            //     console.log('Image URL: ' + profile.getImageUrl());
            //     console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.
            // }
        </script>
        <?php

    }

    function add_meta()
    {

        ?>
<style>
 div.sssbutton{
                width:100%;
                float:left;
                margin-bottom: 10px;

            }
.woocommerce div.sssbutton{
width:49%;
}
            div.sssbutton img{
                width: 100%;
            }
            .woocommerce  .sssSocialButton .sssbutton:first-child{
                margin-right: 2%;
            }
</style>

        <!-- <meta name="google-signin-client_id"
               content="676810173682-ng4feff6v972g6olce047rfm8e4udtlb.apps.googleusercontent.com"> -->

        <?php
    }

    function fb_html()
    {
        ?>
      

        <div class="sssSocialButton">




            <div id="facebookSignIn" class="sssbutton" onClick="checkLoginState()" ><img src="<?php echo get_stylesheet_directory_uri() ?>/sss/images/login-with-facebook.png" alt="Log in With Facebook" title="Log in With Facebook" /></div>

            <div id="googleSignIn" class="sssbutton"><img src="<?php echo get_stylesheet_directory_uri() ?>/sss/images/signingoogle.png" alt="Sign In With Google" title="Sign In With Google" /></div>
        </div>
        <script src="https://apis.google.com/js/platform.js?onload=onSSSLoadGoogleCallback" async defer></script>
        <script>
            window.onSSSLoadGoogleCallback= function() {
                gapi.load('auth2', function () {
                    auth2 = gapi.auth2.init({
                        client_id: '<?php echo SSS_GOOGLEKEY ?>',
                        cookiepolicy: 'single_host_origin',
                        scope: 'profile'
                    });

                    auth2.attachClickHandler(element, {},
                        function (googleUser) {
                            var profile = googleUser.getBasicProfile();
                            console.log(profile);
                            sssSocialLogin(profile.getEmail(), profile.getId(), 'google', profile.getGivenName(),
                                profile.getFamilyName())

                        }, function (error) {
                            console.log(error);
                        }
                    );
                });


                element = document.getElementById('googleSignIn');
            }
        </script>
        <?php
    }


    function socialLoginAction()
    {


        if (is_user_logged_in()) {
            $return['status'] = 'error';
            $return['msg'] = __("You cant accesss this directly", ETHEME_DOMAIN);
            echo json_encode($return);
            wp_die();
        }

        if (isset($_REQUEST['sss_sociallogin']) && isset($_REQUEST['id'])) {

            if (!isset($_REQUEST['email'])) $_REQUEST['email'] = $_REQUEST['id'] . '@' . $_REQUEST['type'] . 'com';
            $ID = email_exists($_REQUEST['email']);

            if ($ID == false) { // Real register
                require_once(ABSPATH . WPINC . '/registration.php');
                $random_password = wp_generate_password($length = 12, $include_standard_special_chars = false);

                $username = strtolower($_REQUEST['first_name'] . " " . $_REQUEST['last_name']);
                $sanitized_user_login = sanitize_user($username);
                if (!validate_username($sanitized_user_login)) {
                    $sanitized_user_login = sanitize_user($_REQUEST['type'] . "_" . $_REQUEST['id']);
                }
                $defaul_user_name = $username;
                $i = 1;
                while (username_exists($sanitized_user_login)) {
                    $sanitized_user_login = sanitize_user($defaul_user_name . "_" . $i);
                    $i++;
                }

                $ID = wp_create_user($sanitized_user_login, $random_password, $_REQUEST['email']);
                if (!is_wp_error($ID)) {
                    wp_new_user_notification($ID, $random_password);
                    $user_info = get_userdata($ID);
                    wp_update_user(array(
                        'ID' => $ID,
                        'display_name' => $defaul_user_name,
                        'first_name' => $_REQUEST['first_name'],
                        'last_name' => $_REQUEST['last_name']
                    ));

                    update_user_meta($ID, $_REQUEST['type'] . '_unique_id', $_REQUEST['id']);

                } else {
                    $return['status'] = 'error';
                    $return['msg'] = __("Something went wrong!. Please try again later", ETHEME_DOMAIN);
                    echo json_encode($return);
                    wp_die();
                }
            }


            if ($ID) { // Login


                $user_info = get_userdata($ID);


                wp_set_current_user($ID, $user_info->user_login);
                wp_set_auth_cookie($ID, true);
                update_user_meta($ID, $_REQUEST['type'] . '_unique_id', $_REQUEST['id']);
                do_action('wp_login', $user_info->user_login, $user_info);

                $return['status'] = 'success';
                $return['msg'] = __("", ETHEME_DOMAIN);
                echo json_encode($return);
            }


        }
        $return['status'] = 'error';
        $return['msg'] = __("Something went wrong!. Please try again later", ETHEME_DOMAIN);
        echo json_encode($return);
        wp_die();
    }
}

SocialLogin::instance();