<?php
/**
 * Checkout shipping information form
 *
 * @author 		cosmeagardens
 * @package 	WooCommerce/Templates
 * @version     3.6.1
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly
global $woocommerce;
@session_start();



if(isset($_SESSION['cshiping'])){

    unset($_SESSION['cshiping']);

}


?>

<h3 class="step-title"><span><?php _e('Who do you want to send the flowers to?', ETHEME_DOMAIN); ?></span></h3>
<p class="form-row required-symbol">Required <label><abbr class="required" title="required">*</abbr></label></p>
<?php
if (empty($_POST)) {

            $ship_to_different_address = get_option('woocommerce_ship_to_billing') === 'no' ? 1 : 0;
            $ship_to_different_address = apply_filters('woocommerce_ship_to_different_address_checked', $ship_to_different_address);
        } else {

    $ship_to_different_address = $checkout->get_value('ship_to_different_address');
}
?>
<div id="ship-to-different-address" style="display: none">
    <input id="ship-to-different-address-checkbox"
           class="input-checkbox" <?php checked($ship_to_different_address, 1); ?> type="checkbox"
           name="ship_to_different_address" value="1" checked/>
    <label for="ship-to-different-address-checkbox"
           class="checkbox"><?php _e('Ship to different address?', 'woocommerce'); ?></label>
</div>
<!-- Nav tabs -->
<?php
if (is_user_logged_in()) { ?>


    <div class="tab-recipient">
        <ul class="nav nav-tabs" role="tablist">
            <li role="presentation" class="active"><a href="#singlerecipient" aria-controls="home" role="tab"
                                                      data-toggle="tab">Single Recipient</a></li>
            <li role="presentation"><a href="#multiplerecipient" aria-controls="profile" role="tab"
                                       data-toggle="tab">Multiple Recipient</a></li>
        </ul>


    </div>
<?php } ?>

<!-- Tab panes -->
<div class="tab-content">

    <div role="tabpanel" class="tab-pane" id="multiplerecipient">
        <div class="woocommerce-shipping-fields">
            <div class="shipping_address">

                <div class="multiple_shipwrap">
                    <?php
                    wc_get_template('checkout/multplerevieworder.php', array('checkout' => WC()->checkout()));

                    ?>
                </div>
            </div>
        </div>
    </div>
    <div role="tabpanel" class="tab-pane active" id="singlerecipient">

        <div class="woocommerce-shipping-fields">
            <?php if (WC()->cart->needs_shipping_address() === true) : ?>


            <div class="shipping_address">
                <?php do_action('woocommerce_checkout_login_form', $checkout); ?>


                <div class="wrap_shipping1">
                    <div class="clearfix"></div>

                <?php do_action('woocommerce_before_checkout_shipping_form', $checkout); ?>

                <?php foreach ($checkout->checkout_fields['shipping'] as $key => $field) : ?>

                    <?php woocommerce_form_field($key, $field, $checkout->get_value($key)); ?>

                <?php endforeach; ?>

                <?php do_action('woocommerce_after_checkout_shipping_form', $checkout); ?>

                <?php do_action('woocommerce_after_checkout_billing_form', $checkout); ?>

            <?php endif; ?>

                    <div class="clearfix"></div>
                </div>
            </div>
        </div>

    </div>
</div>
<script>
    jQuery(document).ready(function () {
        jQuery('.multiple_shipwrap .mainItem .wcmca_product_address_select_menu').select2().on("select2:select", function (e) {
            jQuery(this).trigger('cchange');
        });

        jQuery(document).on('cchange', '.multiple_shipwrap .mainItem .wcmca_product_address_select_menu', function () {

            var uniqid = jQuery(this).data('unique-id');
            var obj = jQuery(this);
            console.log(uniqid);
            if (jQuery("#" + uniqid).length > 0) {
                var string = obj.val().split('-||-');

                console.log(string);
                string.shift();
                var str = jQuery("#" + uniqid + " select").data('unique-id') + '-||-' + string[0] + '-||-' + string[1]

                console.log("#" + uniqid + " select");
                jQuery("#" + uniqid + " select option[value='" + str + "']").prop("selected", "true").trigger('change');

                console.log(jQuery("#" + uniqid + " select").val())
            }

        });
        jQuery('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            if (e.target.text == 'Multiple Recipient') {
                jQuery('.multiple_shipwrap .wcmca_product_address_select_menu').each(function () {
                    if (jQuery(this).val() == '' || jQuery(this).val() == null) {
                        jQuery(this).find('option').eq(0).prop('selected', true).trigger('change')
                    }
                });
                jQuery('.sbilladdress').hide();
                jQuery("#same_fields").prop("checked", false);
                jQuery('#ship-to-different-address-checkbox').prop("checked", true).trigger('chnage');
            } else if (e.target.text == 'Single Recipient') {
                jQuery('.sbilladdress').show();
                jQuery('.multiple_shipwrap .wcmca_product_address_select_menu').each(function () {
                    jQuery(this).find('option').eq(0).prop('selected', true).trigger('change')
                })
                jQuery('#ship-to-different-address-checkbox').prop("checked", false).trigger('change');
            }
        })
    });
</script>