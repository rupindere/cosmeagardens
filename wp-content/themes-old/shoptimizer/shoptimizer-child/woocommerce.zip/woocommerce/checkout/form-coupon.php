<?php
/**
 * Checkout coupon form
 *
 * @author 		cosmeagardens
 * @package 	WooCommerce/Templates
 * @version     3.4.4
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

if ( ! WC()->cart->coupons_enabled() ) {
	return;
}

//$info_message = apply_filters( 'woocommerce_checkout_coupon_message', __( '<a href="#" class="showcoupon">Special Code</a>', 'woocommerce' ) );
$info_message = '<div class="step-title"><span>'.apply_filters( 'woocommerce_checkout_coupon_message', __( 'Have a coupon?', 'woocommerce' ) ).'</span></div>';
wc_print_notice( $info_message, 'notice' );
?>


<div id="coupon_form">

<div class="coupon">

					<input type="text" placeholder="Enter code" value="" id="coupon_code" class="input-text pull-left col-lg-8 col-md-7" name="coupon_code"> <input type="submit" value="Apply Coupon" name="apply_coupon" class="btn pull-right big">

					
				</div>
	

	<div class="clear"></div>
</div>
