<?php
/**
 * Checkout Form
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/checkout/form-checkout.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


?>
<style>
/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 99999; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
/* Modal Content */
.modal-content {
  background-color: #fefefe;
  margin: auto;
  padding: 20px;
  border: 1px solid #888;
  width: 80%;
}
#myBtn1 {
    text-decoration: underline;
    font-size: 16px;
}
/* The Close Button */
.close {
  color: #aaaaaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #000;
  text-decoration: none;
  cursor: pointer;
}
</style>

<?php

// If checkout registration is disabled and not logged in, the user cannot checkout
if ( ! $checkout->enable_signup && ! $checkout->enable_guest_checkout && ! is_user_logged_in() ) {
	echo apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) );
	return;
}

?>
<div class="custom-set">
 <div class="before-checkout-form">
    <?php
do_action( 'woocommerce_before_checkout_form', $checkout );
        //do_action( 'woocommerce_checkout_coupon_form', $checkout );
    ?>
</div>
</div>
<form name="checkout" method="post" class="checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data">
<div class="row">
        <div class="col-lg-7 col-md-7">
    <?php if ( $checkout->get_checkout_fields() ) : ?>

        <?php do_action( 'woocommerce_checkout_before_customer_details' ); ?>

        <div class="col2-set" id="customer_details">
            <div class="col-1">
                <?php do_action( 'woocommerce_checkout_shipping' ); ?>
            </div>
            <div class="col-2">
                        <?php do_action( 'woocommerce_checkout_billing' ); ?>
        <div class="clearfix"></div>
                    </div>
                    <div class="col-3">
                    <?php
					 if ( ! is_user_logged_in() && $checkout->enable_signup ) : ?>
		<?php if ( $checkout->enable_guest_checkout ) : 
					 do_action( 'woocommerce_signup_optional_form', $checkout );
					 endif;
					 endif;
					 ?>
                     <div class="clearfix"></div>
                    </div>

        </div>

        <?php do_action( 'woocommerce_checkout_after_customer_details' ); ?>

    <?php endif; ?>
    </form>
    </div>
    
    <div class="col-lg-5 col-md-5">
       
            <div class="order-review">
            
            <?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>
                <h3 class="step-title"><span><?php _e( 'Your order', 'woocommerce' ); ?></span></h3>
                <?php do_action( 'woocommerce_checkout_before_order_review' ); ?>

                <div id="order_review" class="woocommerce-checkout-review-order">
                
                    <?php do_action( 'woocommerce_checkout_order_review' ); ?>
             
                    
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <?php echo woocommerce_order_review(); ?>
    
  </div>

</div>

<script>
// Get the modal
var modal = document.getElementById("myModal");

// Get the button that opens the modal
var btn = document.getElementById("myBtn1");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
  modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}
</script>
                   <?php echo woocommerce_checkout_payment(); ?>
                </div>

                <?php do_action( 'woocommerce_checkout_after_order_review' ); ?>
                
            </div>
        </div>
 
    </div>

<div>

 
<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>