<input type="checkbox" value="1" name="createaccount" id="createaccount" class="input-checkbox">
<h3 class="step-title"><span>Create an account (optional)</span></h3>
<div class="tform create-account">
<div>    Password
   <input type="password" name="account_password" id="account_password"  class="validate-required" pattern="(?=.*\d).{6,}" title="Please create a password with at least 6 letters and 1 number">
</div>
<div style="float:right;">
   Confirm password:
   <input type="password" name="account_password2"  class="validate-required" id="account_password2" onchange="Validate()">
</div>
<div style="clear:both; float:none"></div>
<span class="instruction" style="margin:0 !important; display:block">(At Least 6 letters and 1 number required)</span>
</div>

<script>
function Validate() {
        var password = jQuery("#account_password").val();
		if(password.length<7){
			alert("At Least 6 letters and 1 number required")
			return false;
			}
        var confirmPassword = jQuery("#account_password2").val();
        if (password != confirmPassword) {
            alert("Passwords do not match.");
			jQuery("#cpword").focus();
            return false;
        }
        return true;
    }

</script> 
