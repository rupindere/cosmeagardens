<?php
/**
 * Checkout billing information form
 *
 * @author 		cosmeagardens
 * @package 	WooCommerce/Templates
 * @version     3.6.0
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<?php if ( WC()->cart->ship_to_billing_address_only() && WC()->cart->needs_shipping() ) : ?>

		<h3 class="step-title"><span><?php _e( 'Billing & Details', 'woocommerce' ); ?></span></h3>

	<?php else : ?>
    <h3 class="step-title"><span><?php _e( 'Your Billing Information', 'woocommerce' ); ?></span></h3>
		<p class="form-row required-symbol">Required <label><abbr class="required" title="required">*</abbr></label></p>
	<?php endif; ?>
<div class="woocommerce-billing-fields">
<div class="billing_address_custom">
<div style="margin-bottom:20px" class="sbilladdress">
<label for="same_fields"></label><input type="checkbox" id="same_fields" /> Same as Shipping address?</div>
<div class="clearfix"></div>
	<?php do_action( 'woocommerce_before_checkout_billing_form', $checkout ); ?>

	<?php foreach ( $checkout->checkout_fields['billing'] as $key => $field ) : ?>

		<?php woocommerce_form_field( $key, $field, $checkout->get_value( $key ) ); ?>

	<?php endforeach; ?>

	<?php do_action('woocommerce_after_checkout_billing_form', $checkout ); ?>

<?php do_action( 'woocommerce_before_order_notes', $checkout ); ?>

	<?php if ( apply_filters( 'woocommerce_enable_order_notes_field', get_option( 'woocommerce_enable_order_comments', 'yes' ) === 'yes' ) ) : ?>

		<?php if ( ! WC()->cart->needs_shipping() || WC()->cart->ship_to_billing_address_only() ) : ?>

			<h3><?php _e( 'Additional Information', 'woocommerce' ); ?></h3>

		<?php endif; ?>

		<?php foreach ( $checkout->checkout_fields['order'] as $key => $field ) : ?>

			<?php woocommerce_form_field( $key, $field, $checkout->get_value( $key ) ); ?>

		<?php endforeach; ?>
        
<p id="order_surprise_field" class="form-row form-row form-row"><label class="checkbox ">
<input type="hidden" name="_mc4wp_subscribe_woocommerce" value="0">
<label><input type="checkbox" name="_mc4wp_subscribe_woocommerce" value="1" checked class="input-checkbox"><span>Please send me email about special offers new products and promotions.</span></label>
		<!--				<input type="checkbox" checked="checked" value="1" id="special_offer" name="special_offer" class="input-checkbox "> </label>--></p>
	<?php endif; ?>

	<?php do_action( 'woocommerce_after_order_notes', $checkout ); ?>
</div>
</div>