<?php
global $etheme_responsive;
$fd = etheme_get_option('footer_demo');
$fbg = etheme_get_option('footer_bg');
$fcolor = etheme_get_option('footer_text_color');
$ft = '';
$ft = apply_filters('custom_footer_filter', $ft);
$custom_footer = etheme_get_custom_field('custom_footer', et_get_page_id());
/**
 * Thankyou page
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.7.0
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>
<script src="<?php echo get_stylesheet_directory_uri();?>/js/html5lightbox.js"></script>
<?php if ($order) :
/*echo"<pre>";
print_r($order->get_items());
echo"</pre>";*/
foreach ($order->get_items() as $item_id => $item) {
	$delivery_date = $item['delivery_date'];
	}
	//echo $delivery_date;
$delivery_date = explode('/', $delivery_date);
$delivery_date = $delivery_date[1]."/".$delivery_date[0]."/".$delivery_date[2];

$delivery_time = get_post_meta( $order->get_order_number(), 'shipping_prefered_delivery_time', true );
if($delivery_time=='funeral')
		{
			$delivery_time.=" : ".get_post_meta( $order->get_order_number(), '_shipping_funeral_time', true );
		}
$delivery_time = ucfirst(str_replace('_',' ',$delivery_time));

    ?>

    <?php if ($order->has_status('failed')) : ?>

        <p><?php _e('Unfortunately your order cannot be processed as the originating bank/merchant has declined your transaction.', 'woocommerce'); ?></p>

        <p><?php
        if (is_user_logged_in())
            _e('Please attempt your purchase again or go to your account page.', 'woocommerce');
        else
            _e('Please attempt your purchase again.', 'woocommerce');
        ?></p>

        <p>
            <a href="<?php echo esc_url($order->get_checkout_payment_url()); ?>" class="button pay"><?php _e('Pay', 'woocommerce') ?></a>
        <?php if (is_user_logged_in()) : ?>
                <a href="<?php echo esc_url(wc_get_page_permalink('myaccount')); ?>" class="button pay"><?php _e('My Account', 'woocommerce'); ?></a>
            <?php endif; ?>
        </p>

    <?php else :  
   // print_r($order);
    ?>
        <div class="order-wrapper">
            <div class="thankyou-text">
                <h1>Thank you for your order.</h1>
                <h2>We are processing it now. You will receive an email confirmation shortly.</h2>
                <p>Visit order status to make changes to your order, track your shipment and more. We recommend you print this page and write down your Order Number below.</p>
            </div>
            <div class="col-sm-6">
                <h2 class="order-heading">Order Details</h2>

                <table class="order-details">
                    <tr>
                        <td><?php _e('Order Date:', 'woocommerce'); ?></td>
                        <td><?php echo date('d M Y', strtotime($order->order_date)); ?></td>
                    </tr>
                     <tr>
                        <td><?php _e('Delivery Date:', 'woocommerce'); ?></td>
                        <td><?php echo date('d M Y', strtotime($delivery_date)); ?></td>
                    </tr>
                     <tr>
                        <td><?php _e('Prefered Delivery time:', 'woocommerce'); ?></td>
                        <td><?php echo $delivery_time; ?></td>
                    </tr>
                    <tr>
                        <td><?php _e('Payment Method:', 'woocommerce'); ?></td>
                        <td><?php echo $order->get_formatted_order_total(); ?> on <?php echo $order->payment_method_title; ?></td>
                    </tr>
                    <tr>
                        <td><strong><?php _e('Order Number:', 'woocommerce'); ?></strong></td>
                        <td><strong><?php echo $order->get_order_number(); ?></strong></td>
                    </tr>
                    <tr>
                        <td><?php _e('Shipping Address:', 'woocommerce'); ?></td>
                        <td><?php echo $order->get_formatted_shipping_address(); ?><br />
                        <?php $shipping_phone = get_post_meta($order->id, 'shipping_phone', true);?>
                        (Phone) : <?php echo $shipping_phone;?></td>
                    </tr>
                    <tr>
                        <td><?php _e('Billing Address:', 'woocommerce'); ?></td>
                        <td><?php echo $order->get_formatted_billing_address(); ?>
                        
                        
                        </td>
                    </tr>
                    <tr>
                        <td><?php _e('Email Confirmation Address:', 'woocommerce'); ?></td>
                        <td><?php echo $order->billing_email; ?></td>
                    </tr>
                    
                    <tr>
                        <td><?php _e('Telephone:', 'woocommerce'); ?></td>
                         <td><?php echo $order->billing_phone; ?></td>
                         
                         <!--<td><?php// _e('Telephone:', 'woocommerce'); ?></td>
                        <td><?php //echo get_post_meta($order->id, 'shipping_phone', true); ?></td>-->
                    </tr>
                                      
                </table>
            </div>
            <div class="col-sm-6"><h2 class="order-heading">Questions About Your Order?</h2>
                <table class="order-details">
                    <tr>
                        <td><?php _e('Email:', 'woocommerce'); ?></td>
                        <td> info@cosmeagardens.com </td>
                        <td><?php //echo get_post_meta($order->id, 'shipping_email', true); ?></td>
                    </tr>
                    <tr>
                        <td><?php _e('Telephone:', 'woocommerce'); ?></td>
                        <td> +357-24-638777 </td>
                        <td><?php //echo get_post_meta($order->id, 'shipping_phone', true); ?></td>
                        
                        <td><?php //echo get_post_meta($order->id, 'custome_price', true); ?></td>
                        
                    </tr>
                </table>

            </div>
            <div class="clear"></div>
            <a class="button" href="<?php echo get_permalink(woocommerce_get_page_id('shop')); ?>">Continue Shopping</a>
        </div>
    <?php endif; ?>
    
    <?php //do_action( 'woocommerce_thankyou_' . $order->payment_method, $order->id ); ?>
        <?php do_action('woocommerce_thankyou_custom', $order->id); ?>
        
   
    <?php else : ?>

    <p><?php echo apply_filters('woocommerce_thankyou_order_received_text', __('Thank you. Your order has been received.', 'woocommerce'), null); ?></p>

<?php endif; ?>

<div class="order-wrapper survey">
    <div class="col-sm-10">
        <h1>Customer Survey</h1>
        <h2>Your Opinion Counts and we Reward you for it!</h2>
        <p>We would love to hear about your shopping experience at CosmeaGardens.com. Upon completing the survey you will be given a discount coupon for your next order.</p>
    </div>
    <div class="col-sm-2 rightimg"><a href="https://docs.google.com/forms/d/e/1FAIpQLSfed2kusOryBC1Jo_ZCuG3Cn5kKcHnzdoDiKuA7IE0OQgPyTg/viewform?embedded=true" class="html5lightbox" data-width="960" data-height="600"><img src="<?php echo get_stylesheet_directory_uri(); ?>/survey.jpg" /></a></div>
    <div class="clear"></div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
<div class="bg_light_pink thankyoupage">
   <div class="subscribe_form_backend" style="display:block">
      <?php
         
         /* ------- News-letter Block----*/
         echo et_get_block(17995);
         ?>
         
<div class="container satisfaction_gurantee" style="display:block">
<div class="col-lg-4">
<?php 
echo et_get_block(18056);
?>
</div>
<div class="col-sm-6">
<div class="delivery_content_top">
<?php 
echo et_get_block(18236);
?>
<div class="clearfix"></div>
<div class="delivery_content_bottom">
 <?php
/* ------- Testimonials ----*/
checkout_footer('asddas');
?>
</div>
</div>
</div>
<div class="col-sm-6 col-lg-2 cards">
<?php 
echo et_get_block(18240);
?>
</div>
</div>
      
      <div class="container custom_menu_footer">
         <?php echo et_get_block(17306); ?>  
      </div>
      
     
      <div class="clearfix"></div>
   </div>
</div>

<!-------------------custom----------------->
<div class="footer-text">
   
      <div class="container footer-2-bottom">
         <div class="footer_text">
            <?php echo et_get_block(18070); ?>
         </div>
      </div>
     
   </div>
</div>
</div>

<?php do_action('after_page_wrapper'); ?>



<?php if (etheme_get_option('loader')): ?>
    <script type="text/javascript">
	jQuery(".html5lightbox").html5lightbox();
        if (jQuery(window).width() > 1200) {
            jQuery("body").queryLoader2({
                barColor: "#111",
                backgroundColor: "#fff",
                percentage: true,
                barHeight: 2,
                completeAnimation: "grow",
                minimumTime: 500,
                onLoadComplete: function () {
                    jQuery('body').addClass('page-loaded');
                }
            });
        }
    </script>
<?php endif; ?>

<?php if (etheme_get_option('to_top')): ?>
    <div id="back-top" class="back-top <?php if (!etheme_get_option('to_top_mobile')): ?>visible-lg<?php endif; ?> bounceOut">
        <a href="#top">
            <span></span>
        </a>
    </div>
<?php endif ?>

<div>

<?php
/* Always have wp_footer() just before the closing </body>
 * tag of your theme, or you will break many plugins, which
 * generally use this hook to reference JavaScript files.
 */

wp_footer();
?>
</body>
</html>