<?php
/**
 * Order details
 *
 * @author      cosmeagardens
 * @package     WooCommerce/Templates
 * @version     3.4.1
 */
if (!defined('ABSPATH')) {
    exit;
}

$order = wc_get_order($order_id);
/*
echo "<pre>";
print_r($order->get_items());
echo "</pre>";*/
?>
<h2 class="summary"><?php _e('Order Summary', 'woocommerce'); ?></h2>
<div class="cart-row table-headings">
        <div class="product-name"><?php _e('Product', 'woocommerce'); ?></div>
        <div class="product-msg"><?php _e('Card Message', 'woocommerce'); ?></div>
        
        <div class="product-price"><?php _e('Price', 'woocommerce'); ?></div>
        <!--div class="product-quantity"><?php _e('Quantity', 'woocommerce'); ?></div-->
        </div>
<div class="table-responsive">

<table class="shop_table table order_details table-bordered">
    
    <tbody>
        <?php foreach ($order->get_items() as $item_id => $item) { ?>

            <?php
            wc_get_template('order/order-details-item.php', array(
                'order' => $order,
                'item_id' => $item_id,
                'item' => $item,
                'product' => apply_filters('woocommerce_order_item_product', $order->get_product_from_item($item), $item)
            ));
        }
        ?>
        <?php do_action('woocommerce_order_items_table', $order); ?>
    </tbody>
    <tfoot>
<?php
foreach ($order->get_order_item_totals() as $key => $total) {
    ?>
            <tr>
                <td scope="row" colspan="4" class="text-right" style="padding-right:20px"><?php echo $total['label']; ?></th>
                <td scope="row" colspan="3" style="padding-left:20px"><strong><?php echo $total['value']; ?></strong></td>
            </tr>
    <?php
}
?>
    </tfoot>
</table>
</div>
<?php do_action('woocommerce_order_details_after_order_table', $order); ?>
<div class="clearfix"></div>
<?php //wc_get_template( 'order/order-details-customer.php', array( 'order' =>  $order ) ); ?>
