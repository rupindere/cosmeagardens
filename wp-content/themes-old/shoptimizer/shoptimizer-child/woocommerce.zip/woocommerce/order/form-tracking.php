<?php
/**
 * Order tracking form
 *
  * @author 	cosmeagardens
 * @package 	WooCommerce/Templates
 * @version     3.6.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

global $post;

?>

<form action="<?php echo esc_url( get_permalink( $post->ID ) ); ?>" method="post" class="track_order">

	<p class="form-row form-row-wide">
				<label class="mandatory_label"><?php _e( 'Required', 'woocommerce' ); ?> <span class="required">*</span></label>
				
			</p>
            <div class="clearfix"></div>
			<p class="form-row form-row-wide"><label for="orderid"><?php _e( 'Order ID', 'woocommerce' ); ?> <span class="required">*</span></label><input class="input-text" type="text" name="orderid" id="orderid" placeholder="<?php esc_attr_e( 'Found in your order confirmation email.', 'woocommerce' ); ?>" required="required" />
			</p>
			<p class="form-row form-row-wide">
				 <label for="order_email"><?php _e( 'Billing Email', 'woocommerce' ); ?> <span class="required">*</span></label> <input class="input-text" type="text" name="order_email" id="order_email" placeholder="<?php esc_attr_e( 'Email you used during checkout.', 'woocommerce' ); ?>" required="required" />
			</p>
	<div class="clear"></div>

	<p class="form-row form-row-wide">
			<label></label><input type="submit" class="btn btn-black big pull-left" name="track" value="<?php esc_attr_e( 'Track', 'woocommerce' ); ?>" /></p>
	<?php wp_nonce_field( 'woocommerce-order_tracking' ); ?>

</form>
