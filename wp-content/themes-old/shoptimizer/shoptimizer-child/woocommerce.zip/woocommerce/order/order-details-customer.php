<?php
/**
 * Order Customer Details
 *
  * @author     Cosmeagardens
 * @package     WooCommerce/Templates
 * @version     3.4.4
 */
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="col-sm-12 order-wrapper">
    
        <h2 class="order-heading"><?php _e('Customer Details', 'woocommerce'); ?></h2>
        <table class="shop_table shop_table_responsive customer_details order-details">
            <?php if ($order->customer_note) : ?>
                <tr>
                    <td><?php _e('Note:', 'woocommerce'); ?></td>
                    <td><?php echo wptexturize($order->customer_note); ?></td>
                </tr>
            <?php endif; ?>

            <?php if ($order->billing_email) : ?>
                <tr>
                    <td><?php _e('Email:', 'woocommerce'); ?></td>
                    <td><?php echo esc_html($order->billing_email); ?></td>
                </tr>
            <?php endif; ?>

            <?php if ($order->billing_phone) : ?>
                <tr>
                    <td><?php _e('Telephone:', 'woocommerce'); ?></td>
                    <td><?php echo esc_html($order->billing_phone); ?></td>
                </tr>
            <?php endif; ?>

            <?php do_action('woocommerce_order_details_after_customer_details', $order); ?>
        </table>
     <div class="clearfix"></div>
</div>

<?php if (!wc_ship_to_billing_address_only() && $order->needs_shipping_address()) : ?>

    <div class="col-sm-12 order-wrapper" style="margin:15px 0px 30px; padding:15px 0px">

        <div class="col-sm-6">

        <?php endif; ?>

        <h2 class="order-heading"><?php _e('Billing Address', 'woocommerce'); ?></h2>
        <address>
            <?php echo ( $address = $order->get_formatted_billing_address() ) ? $address : __('N/A', 'woocommerce'); ?>
        </address>

        <?php if (!wc_ship_to_billing_address_only() && $order->needs_shipping_address()) : ?>

        </div><!-- /.col-1 -->
        <div class="col-sm-6">
            <h2 class="order-heading"><?php _e('Shipping Address', 'woocommerce'); ?></h2>
            <address>
                <?php echo ( $address = $order->get_formatted_shipping_address() ) ? $address : __('N/A', 'woocommerce'); ?>
            </address>
        </div><!-- /.col-2 -->
       
    </div>

<?php endif; ?>