<?php
/**
 * Order Item Details
 *
 * @author      cosmeagardens
 * @package     WooCommerce/Templates
 * @version     3.7.0
 */
if (!defined('ABSPATH')) {
    exit;
}

if (!apply_filters('woocommerce_order_item_visible', true, $item)) {
    return;
}
/*
echo"<pre>";
print_r($product);
echo "</pre>";*/
if (isset($item['main_product_id']) && $item['main_product_id'] != $item['product_id']) {
    $no_border = 'border-top: 0px !important; border-bottom: 0px !important;';
  $prodtype ='<p style="margin-bottom:0"><strong style="font-wietht:600">ADD ON GIFT:</strong></p>';
} else {
    $no_border = 'border-bottom: 0px !important;';
  $prodtype ='';
}
$product = wc_get_product($item['product_id']);
?>

<div class="cart-row">
                        <div class="product-name" style="<?php echo $no_border; ?>">
                                                    <div class="product-thumbnail">  
                                                        <?php
                                                        echo get_the_post_thumbnail($item['product_id'], 'thumbnail');
                                                        ?>
                                                    </div>
                                                    <div class="cart-item-details">
                                                    
                                                        <?php
                            echo $prodtype;
                            echo '<span style="font-weight:500">'.apply_filters('woocommerce_order_item_name', $is_visible ? sprintf('<a href="%s">%s</a>', get_permalink($item['product_id']), $item['name']) : $item['name'], $item, $is_visible).'</span>';?><br />
                                                        Item Number <span><?php echo $product->get_sku(); ?></span>
                                                    </div>
                                                </div>
                                                                                            
                        <div class="product-msg" style="<?php echo $no_border; ?>">
                        <?php if (isset($item['main_product_id']) && $item['main_product_id'] != $item['product_id']) {echo '<p style="margin:0; text-align:center;"><span style="font-weight:500">Occasion: </span>'.$item['occasion']."<br>".$item['gift_message'].'</p>';}else{?>
                        
                              <?php
                if ($item['occasion']!="" ) {
                  
                  if ($item['gift_message']!="") {
                    echo '<p style="margin:0" class="text-center"><span style="font-weight:500">Occasion: </span>'.$item['occasion']."<br>".$item['gift_message'].'</p>';
                  
                   }else{
                   echo '<p style="margin:0" class="text-center"><span style="font-weight:500">Occasion: </span>'.$item['occasion']."<span style='color:#000; font-weight:500; text-align:center; display:block'>No Card Message!</span></p>";
                     }
                }
                      else{if (isset($item['main_product_id']) && $item['main_product_id'] != $item['product_id']) {echo "";}else{echo "<span style='color:#000; font-weight:500; text-align:center; display:block'>No Card Message!</span>";}}
            ?><span style='color:#000; font-weight:500; text-align:center; display:block'>Delivery Date: <?php echo $item['delivery_date']; ?></span><?php }?> </div>
                            
                       
                                            
                        
                        
                        <div class="product-price" style="<?php echo $no_border; ?>">
                            <?php
              

                           // echo $product->price;
                       
                            
                           // if($product->get_sale_price()!=''){
                             //  echo get_woocommerce_currency_symbol().apply_filters('woocommerce_cart_item_price', $product->get_sale_price(), $cart_item, $cart_item_key); 
                           // } else if($product->get_price()!=''){
                               // echo get_woocommerce_currency_symbol().apply_filters('woocommerce_cart_item_price', $product->price, $cart_item, $cart_item_key);
                            //} else if($product->get_regular_price()!=''){
                               //echo get_woocommerce_currency_symbol().apply_filters('woocommerce_cart_item_price', $product->get_regular_price(), $item, $item_id);
                 $subtotal = ($product->price)*$item['qty'];
                 echo wc_price( $subtotal);

                            //}
                            
                            ?>
                        </div>
                        
                        <div class="product-quantity">
                        <?php
                        // allow other plugins to add additional product information here.
		do_action( 'woocommerce_order_item_meta_start', $item_id, $item, $order, $plain_text );

		// allow other plugins to add additional product information here.
		do_action( 'woocommerce_order_item_meta_end', $item_id, $item, $order, $plain_text );
        ?>
                        </div> 
                                            
                            </div>
    

<?php if ($order->has_status(array('completed', 'processing')) && ( $purchase_note = get_post_meta($product->id, '_purchase_note', true) )) : ?>
    <div class="product-purchase-note">
        <?php echo wpautop(do_shortcode(wp_kses_post($purchase_note))); ?>
    </div>
<?php endif; ?>