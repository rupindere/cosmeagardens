<?php
/**
 * Cart Page
 *
 * @author        cosmeagardens
 * @package    WooCommerce/Templates
 * @version     3.5.0
 */
if (!defined('ABSPATH'))
    exit; // Exit if accessed directly

global $woocommerce;
session_start();
wc_print_notices();
checkout_steps_section('3');
do_action('woocommerce_before_cart');
/* echo "<pre>";
  print_r(WC()->cart);
  echo"</pre>"; */

//echo '<pre>'; print_r(WC()->cart->get_cart()); exit;
?>
<?php

$giftmessage = array();
foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
    $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
    if ($cart_item['custom_option']['main_product_id'] != $product_id) {
        $giftmessage[$cart_item['custom_option']['main_product_id']] = $cart_item['custom_option'];
    }
}
?>
    <form class="woocommerce-cart-form" action="<?php echo esc_url(wc_get_cart_url()); ?>" method="post">
        <?php do_action('woocommerce_before_cart_table'); ?>
        <div class="cart-wrapper">
            <h1 class="cart-mobile-heading">Items in Cart</h1>
            <div class="cart-row table-headings">
                <div class="product-name"><?php _e('Product', 'woocommerce'); ?></div>
                <div class="product-msg"><?php _e('Card Message', 'woocommerce'); ?></div>

                <div class="product-price"><?php _e('Price', 'woocommerce'); ?></div>
                <!--div class="product-quantity"><?php _e('Quantity', 'woocommerce'); ?></div-->
                <div class="product-subtotal"><?php _e('Total', 'woocommerce'); ?></div>
            </div>
            <?php

            foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) {
                $delivery_price = 0;
                $delivery_date = $cart_item['custom_option']['delivery_date'];
                ?>
                <?php $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
                //echo '<pre>'; print_r($cart_item['custom_option']['main_product_id']); print_r($product_id);

                if ($_product && $_product->exists() && $cart_item['quantity'] > 0 && apply_filters('woocommerce_cart_item_visible', true, $cart_item, $cart_item_key)) {
                    ?>
                    <?php
                    if (isset($cart_item['custom_option']) && $cart_item['custom_option']['main_product_id'] != $product_id) {
                        $no_border = 'border-top: 0px !important; border-bottom: 0px !important;';
                        $prodtype = '<p style="margin-bottom:0"><strong style="font-wietht:600">ADD ON GIFT:</strong></p>';
                    } else {
                        $no_border = 'border-bottom: 0px !important;';
                        $prodtype = "";
                    }
                    ?>
                    <div class="cart-row">
                        <div class="product-name" style="<?php echo $no_border; ?>">
                            <div class="product-thumbnail">
                                <?php
                                $thumbnail = apply_filters('woocommerce_cart_item_thumbnail', $_product->get_image(), $cart_item, $cart_item_key);

                                /*if (!$_product->is_visible())
                                    echo $thumbnail;
                                else
                                    printf('<a href="%s">%s</a>', $_product->get_permalink(), $thumbnail);*/
                                echo $thumbnail;
                                ?>
                            </div>
                            <div class="cart-item-details">

                                <?php
                                echo $prodtype;
                                echo '<span style="font-weight:500">' . apply_filters('woocommerce_cart_item_name', $_product->get_title(), $cart_item, $cart_item_key) . '</span>'; ?>
                                <br/>
                                Item Number <span><?php echo $_product->get_sku(); ?></span>
                            </div>
                        </div>

                        <div class="product-msg" style="<?php echo $no_border; ?>">

                            <?php
                            $is_print = false;
                            foreach ($giftmessage as $key => $giftitem) {

                                if ($key != $cart_item_key) {

                                    continue;
                                }
                                $is_print = true;
                                if ($giftitem['occasion'] != "") {
                                    if ($giftitem['gift_message'] != "") {
                                        echo '<p style="margin:0" class="text-center"><span style="font-weight:500">Occasion: </span>' . $giftitem['occasion'] . "<br>" . $giftitem['gift_message'] . '</p>';
                                    } else {
                                        echo '<p style="margin:0" class="text-center"><span style="font-weight:500">Occasion: </span>' . $giftitem['occasion'] . "<span style='color:#000; font-weight:500; text-align:center; display:block'>No Card Message!</span></p>";
                                    }
                                } else {
                                    echo "<span style='color:#000; font-weight:500; text-align:center; display:block'>No Card Message!</span>";
                                }
                                ?>
                                <span style="text-align:center;display:block;font-weight:600; color:#A11193">Delivery Date: <?php echo $delivery_date; ?></span>

                                <?php
                            }

                            if(!$is_print && $cart_item['custom_option']['main_product_id'] == $product_id){

                                    echo "<span style='color:#000; font-weight:500; text-align:center; display:block'>No Gift Card!</span>";
                                ?>
                                <span style="text-align:center;display:block;font-weight:600; color:#A11193">Delivery Date: <?php echo $delivery_date; ?></span>

                                <?php
                            }
                            ?>


                        </div>


                        <div class="product-price" style="<?php echo $no_border; ?>">
                            <?php

                            //echo $_product->price;


                            // if($_product->get_sale_price()!=''){
                            //  echo get_woocommerce_currency_symbol().apply_filters('woocommerce_cart_item_price', $_product->get_sale_price(), $cart_item, $cart_item_key);
                            // } else if($_product->get_price()!=''){
                            // echo get_woocommerce_currency_symbol().apply_filters('woocommerce_cart_item_price', $_product->price, $cart_item, $cart_item_key);
                            //} else if($product->get_regular_price()!=''){
                            //echo get_woocommerce_currency_symbol().apply_filters('woocommerce_cart_item_price', $_product->get_regular_price(), $cart_item, $cart_item_key);
                            echo apply_filters('woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal($_product, $cart_item['quantity']), $cart_item, $cart_item_key);
                            //}

                            ?>
                        </div>

                        <!--div class="product-quantity" style="<?php echo $no_border; ?>">
                            <?php
                        if ($_product->is_sold_individually()) {
                            $product_quantity = sprintf('1 <input type="hidden" name="cart[%s][qty]" value="1" />', $cart_item_key);
                        } else {
                            $product_quantity = woocommerce_quantity_input(array(
                                'input_name' => "cart[{$cart_item_key}][qty]",
                                'input_value' => $cart_item['quantity'],
                                'max_value' => $_product->backorders_allowed() ? '' : $_product->get_stock_quantity(),
                                'min_value' => '0'
                            ), $_product, false);
                        }

                        // echo apply_filters('woocommerce_cart_item_quantity', $product_quantity, $cart_item_key, $cart_item);
                        ?>
                           
                        </div-->

                        <div class="product-subtotal" style="<?php echo $no_border; ?>">
                            <?php
                            //echo apply_filters('woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal($_product, $cart_item['quantity']), $cart_item, $cart_item_key);
                            echo apply_filters('woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal($_product, $cart_item['quantity']), $cart_item, $cart_item_key);
                            ?>
                            <?php
                            echo apply_filters('woocommerce_cart_item_remove_link', sprintf('<a href="%s" class="btn remove-item" title="%s">X</a>', esc_url(WC()->cart->get_remove_url($cart_item_key)), __('Remove this item', 'woocommerce')), $cart_item_key);
                            ?>
                        </div>
                    </div>


                    <?php
                }
            }

            do_action('woocommerce_cart_contents');
            ?>

            <?php do_action('woocommerce_after_cart_contents'); ?>


        </div>

        <div class="actions">
            <?php wp_nonce_field('woocommerce-cart'); ?>


        </div>

        <?php do_action('woocommerce_after_cart_table'); ?>

    </form>


    <div class="clearfix"></div>
    <div class="row do-x-col">
        <div class="col-md-6">
            <?php if (WC()->cart->coupons_enabled()) { ?>
                <h3 class="underlined"><?php _e('Have a coupon?', ETHEME_DOMAIN); ?></h3>
                <form class="checkout_coupon" method="post">
                    <div class="coupon">

                        <input type="text" name="coupon_code" class="input-text pull-left col-lg-8 col-md-7"
                               id="coupon_code" value="" placeholder="<?php _e('Enter code', 'woocommerce'); ?>"/>
                        <input type="submit" class="btn pull-right big" name="apply_coupon"
                               value="<?php _e('Apply Coupon', 'woocommerce'); ?>"/>

                        <?php do_action('woocommerce_cart_coupon'); ?>

                    </div>
                </form>

            <?php } ?>
            <div class="space3"></div>

        </div>

        <div class="col-md-6">
            <div class="row">
                <div class="col-xs-12">
                    <div class="cart-collaterals">

                        <?php do_action('woocommerce_cart_collaterals'); ?>

                    </div>
                </div>
            </div>
        </div>
        <?php do_action('woocommerce_proceed_to_shopping'); ?>
    </div>
    <div class="cartdatepicker">
        <?php echo do_shortcode('[get_yc_datepicker]'); //echo $_SESSION['delivery_date'];  ?>
    </div>
<?php woocommerce_cross_sell_display(); ?>
<?php
//do_action( 'woocommerce_after_cart' ); ?>