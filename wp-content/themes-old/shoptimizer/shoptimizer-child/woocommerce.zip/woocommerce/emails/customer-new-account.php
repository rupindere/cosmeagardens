<?php
/**
 * Customer new account email
 *
 * @author 		cosmeagardens
 * @package 	WooCommerce/Templates/Emails
 * @version     3.7.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<?php
global $woocommerce;
        $logoimg = etheme_get_option('logo');
        $logoimg = apply_filters('etheme_logo_src',$logoimg);
		?>
<div style="background:#F7F7F7;">
<table style="background:#fff; border:1px solid #e5e5e5" width="600" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01" >
        <tr class="white" style=" text-align:center; margin:0 auto;">
          <td style="padding:10px"><img src="<?php echo $logoimg ?>" alt="<?php bloginfo( 'description' ); ?>" width="300"></td>
        </tr>
        
        <tr>
        <td>
         <hr>
         <div class="top-navigation" style="text-align: center;">
    <ul style="margin: 0px;padding: 0px;display: inline-block;">
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/shop/?product_cat=birthday" target="_blank" style="text-decoration: none;margin-right: 30px;color: #a11194;
    font-size: 20px;font-weight: 500;font-family: 'Raleway', sans-serif;">Birthday</a></li>
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/product-category/anniversary/" target="_blank" style="text-decoration: none;margin-right: 30px;color: #a11194;
    font-size: 20px;font-weight: 500;font-family: 'Raleway', sans-serif;">Annivesary</a></li>
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/product-category/best-sellers/" target="_blank" style="text-decoration: none;margin-right: 30px;color: #a11194;
     font-size: 20px;font-weight: 500;font-family: 'Raleway', sans-serif;">Best Sellers</a></li>
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/product-category/best-sellers/" target="_blank" style="text-decoration: none;margin-right: 30px;color: #a11194;
    font-size: 20px;font-weight: 500;font-family: 'Raleway', sans-serif;">Specials</a></li>
    </ul>
    <hr>
    </div>
        </td>
        </tr>
<tr class="your-account" style=" text-align:center; margin:0 auto; background:#a11194;">
          <td><h2 style="color: #fff;font-size: 20px;font-weight: 600;margin: 0;padding: 10px 0;text-align: center;  width:100%;"><?php echo $email_heading; ?></h2></td>
        </tr>

<tr class="great-news">
  <td style="padding:10px 20px 0">
  
<?php //do_action('woocommerce_email_header', $email_heading); ?>

<p style="font-size: 14px;"><?php printf( __( "Thanks for creating an account on %s. Your username is <strong>%s</strong>.", 'woocommerce' ), esc_html( $blogname ), esc_html( $user_login ) ); ?></p>

<?php if ( get_option( 'woocommerce_registration_generate_password' ) == 'yes' && $password_generated ) : ?>

	<p style="font-size: 16px;"><?php printf( __( "Your password has been automatically generated: <strong>%s</strong>", 'woocommerce' ), esc_html( $user_pass ) ); ?></p>

<?php endif; ?>

<p style="font-size: 16px;"><?php printf( __( 'You can access your account area to view your orders and change your password here: %s.', 'woocommerce' ), wc_get_page_permalink( 'myaccount' ) ); ?></p>

<table>
<tr>
<td>
	<p style="font-size: 16px;">Sincerely,</p>
    <p style="font-size: 16px;">The CosmeaGardens.com Team</p>
</td>
</tr>
<tr>
<td>
	<img src="<?php echo site_url();?>/wp-content/uploads/2017/05/banner.jpg" style="max-width:100%;">
</td>
</tr>
</table>
<table style="margin:10px auto;">
<tr>
    <td style="border-right: 1px solid #ddd; width:50%; vertical-align:top">
    <div class="socil-icons" style="padding:0 10px;">
    <h2 style="color: #a11194;font-size: 18px;">KEEP IN TOUCH</h2>
    <h4 style="color: #a9a9a9;font-size: 14px;font-weight: normal;margin: 0;margin-top: 6px;">Connect with us for great ideas</h4>
    <ul style="margin: 0px;padding: 0px;margin-top: 20px;">
      <a href="https://www.facebook.com/CosmeaGardens" target="_blank"><img width="40px" src="<?php echo site_url();?>/wp-content/uploads/2017/05/facebook.png"/></a> 
      <a href="https://plus.google.com/+Cosmeagardens2" target="_blank"><img width="40px" src="<?php echo site_url();?>/wp-content/uploads/2017/05/google.png"/></a> 
      <a href="https://twitter.com/CosmeaGardens" target="_blank"><img width="40px" src="<?php echo site_url();?>/wp-content/uploads/2017/05/twitter.png"/></a> 
      <a href="https://www.pinterest.com/cosmeagardens/" target="_blank"><img width="40px" src="<?php echo site_url();?>/wp-content/uploads/2017/05/pinterest.png"/></a>
      <a href="https://www.instagram.com/cosmeagardens/" target="_blank"><img width="40px" src="<?php echo site_url();?>/wp-content/uploads/2019/06/pinterest-3.png"/></a>
    </ul>
  </div>
  </td>
  <td style="vertical-align:top">
  <div class="our-addres" style="padding:0 10px">
    <h2 style="color: #a11194;font-size: 18px;">CONTACT US</h2>
    <h4 style="color: #a9a9a9;font-size: 14px;font-weight: normal;margin: 0;margin-top: 6px;">If you have any Questions or Comments:</h4>
    <p>+ 357-24-638777<br>
<a style="color: #800080;" href="">info@cosmeagardens.com</a><br />
<a style="color: #800080;" href="<?php echo site_url(); ?>" target="_blank">www.cosmeagardens.com</a>

</p>
  </div>
</td>
</tr>
</table>
<table>
<tr>
<td>
<p style="font-size:14px; line-height:25px;text-align:justify;">Send Flowers to Cyprus from CosmeaGardens.com. We are a local florist and we offer bouquets and arrangements delivery all over cyprus including Larnaca, Nicosia, Limassol, Paphos, Ayia Napa and Paralimni. We have got you covered for any occasion. Whether you are sending a dozen of tulips to your mom for Mother's Day or an Arrangements to your coworker wishing congratulations for their achievements.</p>
<h5 style="font-size:16px;">For More Information Click Here:<a href="<?php echo site_url(); ?>" target="_blank" style="color:#a11194;">www.cosmeagardens.com</a></h5>
          
</td>

</tr>
</table>
</td>
</tr>
 </table>
</div>
<?php //do_action( 'woocommerce_email_footer' ); ?>