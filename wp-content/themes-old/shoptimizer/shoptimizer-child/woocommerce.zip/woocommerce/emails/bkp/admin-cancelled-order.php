<?php
/**
 * Customer refunded order email
 *
 * @author 		cosmeagardens
 * @package 	WooCommerce/Templates/Emails
 * @version     3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>
<?php
global $woocommerce;
        $logoimg = etheme_get_option('logo');
        $logoimg = apply_filters('etheme_logo_src',$logoimg);
			foreach ($order->get_items() as $item_id => $item) {
			$delivery_date = $item['delivery_date'];
		}
$delivery_date = explode('/', $delivery_date);
$delivery_date = $delivery_date[1]."/".$delivery_date[0]."/".$delivery_date[2];	
$delivery_time = get_post_meta( $order->get_order_number(), 'shipping_prefered_delivery_time', true ); 
		if($delivery_time=='funeral')
		{
			$delivery_time.=" : ".get_post_meta( $order->get_order_number(), '_shipping_funeral_time', true );
		}
		$delivery_time = ucfirst(str_replace('_',' ',$delivery_time));
		?>

<table width="700" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01" >
        <tr class="white" style=" text-align:center; margin:0 auto;">
          <td><img src="<?php echo $logoimg ?>" alt="<?php bloginfo( 'description' ); ?>" width="300"></td>
        </tr>
        
        <tr>
        <td>
         <hr>
         <div class="top-navigation" style="text-align: center;">
    <ul style="margin: 0px;padding: 0px;display: inline-block;">
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/shop/?product_cat=birthday" target="_blank" style="text-decoration: none;margin-right: 10px;color: #a11194;
    font-size: 13px;font-weight: 500;font-family: 'Raleway', sans-serif;">Birthday</a></li>
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/product-category/anniversary/" target="_blank" style="text-decoration: none;margin-right: 10px;color: #a11194;
    font-size: 13px;font-weight: 500;font-family: 'Raleway', sans-serif;">Annivesary</a></li>
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/product-category/best-sellers/" target="_blank" style="text-decoration: none;margin-right: 10px;color: #a11194;
     font-size: 13px;font-weight: 500;font-family: 'Raleway', sans-serif;">Best Sellers</a></li>
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/product-category/best-sellers/" target="_blank" style="text-decoration: none;margin-right: 10px;color: #a11194;
    font-size: 13px;font-weight: 500;font-family: 'Raleway', sans-serif;">Specials</a></li>
    </ul>
    <hr>
    </div>
        </td>
        </tr>
<tr class="your-account" style=" text-align:center; margin:0 auto; background:#a11194;">
          <td><h2 style="color: #fff;font-size: 16px;font-weight: 600;margin: 0;padding: 10px 0;text-align: center;  width:100%;"><?php echo $email_heading;?></h2></td>
        </tr>

<tr class="great-news">
  <td>
  
<?php //do_action('woocommerce_email_header', $email_heading); ?>

<p><?php printf( __( 'The order #%d from %s has been cancelled. The order was as follows:', 'woocommerce' ), $order->get_order_number(), $order->get_formatted_billing_full_name() ); ?></p>

<table style="width:100%">
<tr>
<td><p style="font-weight:600; font-size:13px"><?php printf( __( 'Order Date: %s', 'woocommerce' ), date('d M Y', strtotime($order->order_date)) ); ?></p>
<p style="font-weight:600; font-size:13px"><?php printf( __( 'Delivery Date: %s', 'woocommerce' ), date('d M Y', strtotime($delivery_date)) ); ?></p>
<!--<p style="font-weight:600; font-size:13px"><?php printf( __( 'Preferred Delivery Time: %s', 'woocommerce' ), $delivery_time ); ?></p>--></td>
<td style="text-align:right; vertical-align:top"><h2 style="text-align:right;font-size: 14px;"><?php printf( __( 'Order Number: %s', 'woocommerce' ), $order->get_order_number() ); ?></h2></td>
</tr>
</table>


<table class="td" width="100%" cellspacing="0" cellpadding="6" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;" border="1">
	<thead>
		<tr>
			<th class="td" scope="col" style="text-align:left;"><?php _e( 'Product', 'woocommerce' ); ?></th>
			<th class="td" scope="col" style="text-align:left;"><?php _e( 'Price', 'woocommerce' ); ?></th>
		</tr>
	</thead>
	<tbody>
		<?php echo $order->email_order_items_table( false, true ); ?>
	</tbody>
	<tfoot>
		<?php
			if ( $totals = $order->get_order_item_totals() ) {
				$i = 0;
				foreach ( $totals as $total ) {
					$i++;
					?><tr>
						<th class="td" scope="row" colspan="2" style="text-align:left; <?php if ( $i == 1 ) echo 'border-top-width: 4px;'; ?>"><?php echo $total['label']; ?></th>
						<td class="td" style="text-align:left; <?php if ( $i == 1 ) echo 'border-top-width: 4px;'; ?>"><?php echo $total['value']; ?></td>
					</tr><?php
				}
			}
		?>
	</tfoot>
</table>

<?php do_action( 'woocommerce_email_after_order_table', $order, true, false ); ?>

<?php do_action( 'woocommerce_email_order_meta', $order, true, false ); ?>

<?php do_action( 'woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text ); ?>

<?php //do_action( 'woocommerce_email_footer' ); ?>
</td>
</tr>

<tr>
<td>
	<p style="font-size: 16px;">Sincerely,</p>
    <p style="font-size: 16px;">The CosmeaGardens.com Team</p>
</td>
</tr>
<td>
	<img src="<?php echo site_url();?>/wp-content/uploads/2017/05/banner.jpg" style="width:100%;">
</td>
<tr>
    <td>
    <div class="socil-icons" style="width: 300px;
    float: left;">
    <h2 style="color: #a11194;font-size: 16px;">KEEP IN TOUCH</h2>
    <h4 style="color: #a9a9a9;font-size: 18px;font-weight: normal;margin: 0;margin-top: 6px;">Connect with us for great ideas</h4>
    <ul style="margin: 0px;padding: 0px;margin-top: 20px;">
      <a href="https://www.facebook.com/CosmeaGardens" target="_blank"><img src="<?php echo site_url();?>/wp-content/uploads/2017/05/facebook.png"/></a> 
      <a href="https://plus.google.com/+Cosmeagardens2" target="_blank"><img src="<?php echo site_url();?>/wp-content/uploads/2017/05/google.png"/></a> 
      <a href="https://twitter.com/CosmeaGardens" target="_blank"><img src="<?php echo site_url();?>/wp-content/uploads/2017/05/twitter.png"/></a> 
      <a href="https://www.pinterest.com/cosmeagardens/" target="_blank"><img src="<?php echo site_url();?>/wp-content/uploads/2017/05/pinterest.png"/></a>
    </ul>
  </div>
  <div class="our-addres" style="width: auto;float: left;margin-left: 0px;">
    <h2 style="color: #a11194;font-size: 16px;">CONTACT US</h2>
    <h4 style="color: #a9a9a9;font-size: 18px;font-weight: normal;margin: 0;margin-top: 6px;">If you have any Questions or Comments:</h4>
    <p><span style="color:#757575">Phone: </span>+ 357-24-638777<br>
<span style="color:#757575;"> Email: </span><a style="color: #800080;" href="">info@cosmeagardens.com</a><br />
<span style="color:#757575;"> Web: </span><a style="color: #800080;" href="<?php echo site_url(); ?>" target="_blank">www.cosmeagardens.com</a>

</p>
  </div>
</td>
</tr>
<tr>
<td>
<p style="font-size:14px; line-height:18px;text-align:left;">Send Flowers to Cyprus from CosmeaGardens.com. We are a local florist and we offer bouquets and arrangement delivery all over cyprus including Larnaca, Nicosia, Limassol, Paphos, Ayia Napa and Paralimni. We have got you covered for any occasion. Whether you are sending a dozen of tulips to your mom for Mother's Day or an Arrangements to your coworker wishing congratulations for their achievements.</p>
<h5 style="font-size:16px;">For More Information Click Here:<a href="<?php echo site_url(); ?>" target="_blank" style="color:#a11194;">www.cosmeagardens.com</a></h5>
          
</td>

</tr>
 </table>


<?php //do_action( 'woocommerce_email_footer' ); ?>