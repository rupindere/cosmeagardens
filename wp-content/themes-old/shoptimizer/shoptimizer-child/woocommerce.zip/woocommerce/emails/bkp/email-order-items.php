<?php
/**
 * Email Order Items
 *
 * @author 		cosmeagardens
 * @package 	WooCommerce/Templates/Emails
 * @version     3.5.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

foreach ( $items as $item_id => $item ) :
if (isset($item['main_product_id']) && $item['main_product_id'] != $item['product_id']) {
    $no_border = 'border-top: 0px !important; border-bottom: 0px !important; border-color:#E4E4E4 !important;';
	$prodtype ='<p style="margin-bottom:0"><strong style="font-wietht:600">ADD ON GIFT:</strong></p>';
} else {
    $no_border = 'border-bottom: 0px !important; border-color:#E4E4E4 !important;';
	$prodtype ='';
}
	$_product     = apply_filters( 'woocommerce_order_item_product', $order->get_product_from_item( $item ), $item );
	$item_meta    = new WC_Order_Item_Meta( $item, $_product );

	if ( apply_filters( 'woocommerce_order_item_visible', true, $item ) ) {?>
		<tr class="<?php echo esc_attr(apply_filters('woocommerce_order_item_class', 'order_item', $item, $order)); ?>">

    <td class="product-name order-thumb" style="border-color: #e4e4e4!important;
    border: 1px solid #e4e4e4;text-align: center;border-style: solid;">
        <div class="product-thumbnail" style="float:left">  
                                                        <?php
														$thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( $item['product_id'] ) );
														echo '<img src="'.$thumbnail[0].'" style="width:50px; height="auto">';
                                                        //echo get_the_post_thumbnail($item['product_id'], 'thumbnail');
                                                        ?>
                                                    </div>
                                                    <div class="cart-item-details" style="float:left; padding-left:15px; text-align:left">
                                                    
                                                        <?php
														echo $prodtype;
														echo '<span style="font-weight:500; color:#9a0589">'.apply_filters('woocommerce_order_item_name', $is_visible ? sprintf('<a href="%s">%s</a>', get_permalink($item['product_id']), $item['name']) : $item['name'], $item, $is_visible).'</span>';?><br />
                                                        Item Number <span style="color:#9a0589"><?php echo $_product->get_sku(); ?></span>
                                                    </div>
    </td>
    <td class="occasion text-center" style="border-color: #e4e4e4!important;
    border-style: solid;">
    <?php if (isset($item['main_product_id']) && $item['main_product_id'] != $item['product_id']) {}else{?>
                       
                              <?php
							  if ($item['occasion']!="" ) {
								  
								  if ($item['gift_message']!="") {
									  echo '<p style="margin:0; text-align:center;"><span style="font-weight:500">Occasion: </span>'.$item['occasion']."<br>".$item['gift_message'].'</p>';
								  
								   }else{
									 echo '<p style="margin:0; text-align:center;"><span style="font-weight:500">Occasion: </span>'.$item['occasion'].'</p>';
									   }
							  }
									    else{if (isset($item['main_product_id']) && $item['main_product_id'] != $item['product_id']) {echo "";}else{echo "<span style='color:#000; font-weight:500; text-align:center; display:block'>No Card Message!</span>";}}
						}?>
   </td>
             
    <td class="product-total" style="border-color: #e4e4e4!important;text-align: center;border-style: solid;">
        <?php echo $order->get_formatted_line_subtotal($item); ?>
    </td>
</tr>
		
		<?php }

	if ( $show_purchase_note && is_object( $_product ) && ( $purchase_note = get_post_meta( $_product->id, '_purchase_note', true ) ) ) : ?>
		<tr>
			<td colspan="3" style="text-align:left; vertical-align:middle; border: 1px solid #eee; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;"><?php echo wpautop( do_shortcode( wp_kses_post( $purchase_note ) ) ); ?></td>
		</tr>
	<?php endif; ?>

<?php endforeach; ?>