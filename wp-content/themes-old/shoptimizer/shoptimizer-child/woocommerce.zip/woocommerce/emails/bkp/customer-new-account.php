<?php
/**
 * Customer new account email
 *
 * @author 		cosmeagardens
 * @package 	WooCommerce/Templates/Emails
 * @version     3.5.2
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<?php //do_action( 'woocommerce_email_header', $email_heading ); 
global $woocommerce;
        $logoimg = etheme_get_option('logo');
        $logoimg = apply_filters('etheme_logo_src',$logoimg);
	
?>

<table width="700" border="0" align="center" cellpadding="0" cellspacing="0" id="Table_01" >
        <tr class="white" style=" text-align:center; margin:0 auto;">
          <td><img src="<?php echo $logoimg; ?>" alt="<?php bloginfo( 'description' ); ?>" width="300"></td>
        </tr>
        
        <tr>
        <td>
         <hr>
         <div class="top-navigation" style="text-align: center;">
    <ul style="margin: 0px;padding: 0px;display: inline-block;">
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/shop/?product_cat=birthday" target="_blank" style="text-decoration: none;margin-right: 10px;color: #a11194;
    font-size: 13px;font-weight: 500;font-family: 'Raleway', sans-serif;">Birthday</a></li>
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/product-category/anniversary/" target="_blank" style="text-decoration: none;margin-right: 10px;color: #a11194;
    font-size: 13px;font-weight: 500;font-family: 'Raleway', sans-serif;">Annivesary</a></li>
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/product-category/best-sellers/" target="_blank" style="text-decoration: none;margin-right: 10px;color: #a11194;
     font-size: 13px;font-weight: 500;font-family: 'Raleway', sans-serif;">Best Sellers</a></li>
      <li style="list-style: none;display: inline-block;"><a href="<?php echo site_url();?>/product-category/best-sellers/" target="_blank" style="text-decoration: none;margin-right: 10px;color: #a11194;
    font-size: 13px;font-weight: 500;font-family: 'Raleway', sans-serif;">Specials</a></li>
    </ul>
    <hr>
    </div>
        
        </td>
        
        </tr>
        
        
        <tr class="your-account1" style=" text-align:center; margin:0 auto; background:#a11194;">
          <td><h2 style="color: #fff;font-size: 16px;font-weight: 600;margin: 0;padding: 10px 0;text-align: center;  width:100%;"><?php echo $email_heading; ?></h2></td>
        </tr>
        
        
        <tr class="great-news">
          <td>
          <p><?php printf( __( "Thanks for creating an account on %s. Your username is <strong>%s</strong>.", 'woocommerce' ), esc_html( $blogname ), esc_html( $user_login ) ); ?></p>

<?php if ( get_option( 'woocommerce_registration_generate_password' ) == 'yes' && $password_generated ) : ?>

	<p><?php printf( __( "Your password has been automatically generated: <strong>%s</strong>", 'woocommerce' ), esc_html( $user_pass ) ); ?></p>

<?php endif; ?>

<p><?php printf( __( 'You can access your account area to view your orders and change your password here: %s.', 'woocommerce' ), wc_get_page_permalink( 'myaccount' ) ); ?></p>
    
          </td>
        </tr>
        
        <tr>
        <td>
        <div class="Earn1">
       
      <p style="font-size:16px; color:#000">Best Regards,<br />
      Customer Service<br />
      CosmeaGardens.com<br />
      +357-24-638777</p>
    
        
        </div>
       
        </td>
        </tr>
        <td>
        <img src="<?php echo site_url();?>/wp-content/uploads/2017/05/banner.jpg" style="width:100%; margin-top:30px;">
        </td>
        
        <tr>
    <td>
    <div class="socil-icons" style="width: 300px;
    float: left;">
    <h2 style="color: #a11194;font-size: 16px;">KEEP IN TOUCH</h2>
    <h4 style="color: #a9a9a9;font-size: 18px;font-weight: normal;margin: 0;margin-top: 6px;">Connect with us for great ideas</h4>
    <ul style="margin: 0px;padding: 0px;margin-top: 20px;">
      <a href="https://www.facebook.com/CosmeaGardens" target="_blank"><img src="<?php echo site_url();?>/wp-content/uploads/2017/05/facebook.png"/></a> 
      <a href="https://plus.google.com/+Cosmeagardens2" target="_blank"><img src="<?php echo site_url();?>/wp-content/uploads/2017/05/google.png"/></a> 
      <a href="https://twitter.com/CosmeaGardens" target="_blank"><img src="<?php echo site_url();?>/wp-content/uploads/2017/05/twitter.png"/></a> 
      <a href="https://www.pinterest.com/cosmeagardens/" target="_blank"><img src="<?php echo site_url();?>/wp-content/uploads/2017/05/pinterest.png"/></a>
    </ul>
  </div>
  <div class="our-addres" style="width: auto;float: left;margin-left: 0px;">
    <h2 style="color: #a11194;font-size: 16px;">CONTACT US</h2>
    <h4 style="color: #a9a9a9;font-size: 18px;font-weight: normal;margin: 0;margin-top: 6px;">If you have any Questions or Comments:</h4>
    <p><span style="color:#757575">Phone: </span>+ 357-24-638777<br>
<span style="color:#757575;"> Email: </span><a style="color: #800080;" href="">info@cosmeagardens.com</a><br />
<span style="color:#757575;"> Web: </span><a style="color: #800080;" href="<?php echo site_url(); ?>" target="_blank">www.cosmeagardens.com</a>

</p>
  </div>
</td>
</tr>
<tr>
<td>
<p style="font-size:14px; line-height:18px;text-align:left;">Send Flowers to Cyprus from CosmeaGardens.com. We are a local florist and we offer bouquets and arrangement delivery all over cyprus including Larnaca, Nicosia, Limassol, Paphos, Ayia Napa and Paralimni. We have got you covered for any occasion. Whether you are sending a dozen of tulips to your mom for Mother's Day or an Arrangements to your coworker wishing congratulations for their achievements.</p>
<h5 style="font-size:16px;">For More Information Click Here:<a href="<?php echo site_url(); ?>" target="_blank" style="color:#a11194;">www.cosmeagardens.com</a></h5>
          
</td>

</tr>
 </table>


<?php //do_action( 'woocommerce_email_footer' ); ?>