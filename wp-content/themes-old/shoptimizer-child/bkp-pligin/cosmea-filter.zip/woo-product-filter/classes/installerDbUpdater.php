<?php
class InstallerDbUpdaterWpf {
	public static function runUpdate() {

	}
}
