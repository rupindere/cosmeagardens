<?php
class Woofilters_WidgetControllerWpf extends ControllerWpf {

}
